console.log("Hello world")

var a1=1;
var b1=2;
var R1=a1+b1;
console.log("Resultado Suma: " + R1);

var a2=5;
var b2=3;
var R2=a2*b2;
console.log("Resultado Multiplicacion: " + R2);

var a3=Math.sqrt(1244);
console.log("Resultado Raiz: " + a3);

var raiz=Math.trunc(a3);
console.log("Resultado Raiz Aproximada: " + raiz);

var c = 500000;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log("Los numero primos hasta el 500.000 son: " + numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}